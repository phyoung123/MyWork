#!/bin/sh

export CUDA_VISIBLE_DEVICES=1

nep_392
