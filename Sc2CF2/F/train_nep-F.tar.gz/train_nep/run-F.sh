#!/bin/sh

export CUDA_VISIBLE_DEVICES=0,1

nep_master
